#include <stdio.h>
#include <math.h>
#define MAX_SIZE 20
#define next_line printf("\n")

struct Matrix readMatrix();
struct Matrix readMatrix_A_from_file();
struct Matrix readMatrix_B_from_file();
void printMatrix(struct Matrix a);
void printMatrix_A_in_file(struct Matrix a);
void printMatrix_B_in_file(struct Matrix b);
int addMatrix(struct Matrix *a, struct Matrix *b, struct Matrix *c);
int subMatrix(struct Matrix *a, struct Matrix *b, struct Matrix *c);
int mulMatrix(struct Matrix *a, struct Matrix *b, struct Matrix *c);
float detMatrix(float A[][MAX_SIZE], int n);
void getCofactor(float A[][MAX_SIZE], float temp[][MAX_SIZE], int p, int q, int n);
float get_cofactor(float matrix[][MAX_SIZE], float matirx_cofactor[][MAX_SIZE], int size);
float trans_invMatrix(float matrix[][MAX_SIZE], float matrix_cofactor[][MAX_SIZE], float m_inverse[][MAX_SIZE], int size);
void transMatrix(float A[][MAX_SIZE], float B[][MAX_SIZE], int m, int n);

struct Matrix {
	float array[MAX_SIZE][MAX_SIZE];
	int m, n;
};


int main() {
	// This is the program's menu
	printf("Welcome!\n");
	printf("This program is designed to do some operations on matrices.\n");
	printf("\nHere are some of the operations that this program can do for you.\n");
	printf("You can only choose one number.\n");
	printf("\n1.Read matrix A from a file\n");
	printf("\n2.Read matrix B from a file\n");
	printf("\n3.Determinant of matrix A\n");
	printf("\n4.Determinant of matrix B\n");
	printf("\n5.Adding two matrices A & B and save the result in A\n");
	printf("\n6.Substracting matrices A & B and save the result in A\n");
	printf("\n7.Multiplication of matrices A & B and save the result in A\n");
	printf("\n8.Inverse of matrix A and save the result in A\n");
	printf("\n9.Inverse of matrix B and save the result in B\n");
	printf("\n10.Calculating transpose of matrix A and save the result in A\n");
	printf("\n11.Calculating transpose of matrix B and save the result in B\n");
	printf("\n12.Save matrix A in a file.\n");
	printf("\n13.Save matrix B in a file.\n");
	printf("\n\n0.Exit\n\n\n\n");
	
	int n;
	 
	printf("Enter the number of your choise:\n");
	scanf("%d", &n);
	
	if(n == 0)
		return 0;
	
	struct Matrix A;
	struct Matrix B;
	struct Matrix C;
	struct Matrix D;
	struct Matrix E;
	struct Matrix F;
	struct Matrix inv;
	struct Matrix c;
	struct Matrix T;
	
	if(n == 3 || n == 5 || n == 6 || n == 7 || n == 8 || n == 10 || n == 12) {
		printf("\nMatrix A\n");
		A=readMatrix();
		printMatrix(A);
		next_line;
	}
	
	if(n == 4 || n == 5 || n == 6 || n == 7 || n == 9 || n == 11 || n == 13) {
		printf("\nMatrix B\n");
		B=readMatrix();
		printMatrix(B);
		next_line;
	}
	
	if(n == 1) {
		A=readMatrix_A_from_file();
		printMatrix(A);
	}
	
	else if(n == 2) {
		B=readMatrix_B_from_file();
		printMatrix(B);
	}
	
	if(n == 5) {
		if(addMatrix(&A,&B,&C) == 1) {
			// Addition A+B
			addMatrix(&A,&B,&C);
			printf("The result of the addtion A+B is:\n");
			A=C;
			printMatrix(A);
			next_line;
		}
		
		else
			printf("\n\nError!\nThe value of rows and columns must be equal.\n");
	}
	
	else if(n == 6) {
		if(subMatrix(&A,&B,&D) == 1) {
			int m;
			printf("\nWhich one do you choose?\n");
			printf("1. A-B\n");
			printf("2. B-A\n");
			scanf("%d", &m);
			if(m == 1) {
				next_line; // Substraction A-B
				subMatrix(&A,&B,&D);
				printf("The result of the substraction A-B is:\n");
				A=D;
				printMatrix(A);
				next_line;
			}
		
			else if(m == 2) {
				next_line; // Substraction B-A
				subMatrix(&B,&A,&D);
				printf("The result of the substraction B-A is:\n");
				A=D;
				printMatrix(A);
				next_line;
			}
		}
		
		else
			printf("\nError!\nThis matrix does not have determinant.\nRows and columns must be equal.\n");
	}
	
	else if(n == 7) {
		int y;
		if(mulMatrix(&A,&B,&E) == 1) {
			int m;
			printf("\nWhich one do you choose?\n");
			printf("1. A*B\n");
			printf("2. B*A\n");
			scanf("%d", &m);
			y=m;
			if(m == 1) {
				next_line; // Multiplication A*B
				mulMatrix(&A,&B,&E);
				printf("The result of the multiplication A*B is:\n");
				A=E;
				printMatrix(E);
				next_line;
			}
		
			else if(m == 2) {
				next_line; // Multiplication B*A
				mulMatrix(&B,&A,&E);
				printf("The result of the multiplication B*A is:\n");
				A=E;
				printMatrix(E);
				next_line;
			}
		}
		
		else if(y == 1)
			printf("\nError!\nThis matrix does not have determinant.\nRows of matrix B and columns of matrix A must be equal.\n");
			
		else if(y == 2)
			printf("\nError!\nThis matrix does not have determinant.\nRows of matrix A and columns of matrix B must be equal.\n");
	}
	
	else if(n == 3) {
		next_line; // Determinant of A
		printf("This is the determinant of matrix A:\n");	
		if(A.m == A.n)
			printf("Determinant: %f\n", detMatrix(A.array,A.m));
		else
			printf("\nError!\nThis matrix does not have determinant.\nRows and columns must be equal.\n");
	}
	
	else if(n == 4) {
		next_line;
		next_line; // Determinant of B
		printf("This is the determinant of matrix B:\n");
		if(B.m == B.n)
			printf("Determinant: %f\n", detMatrix(B.array,B.m));
		else
			printf("\nError!\nThis matrix does not have determinant.\nRows and columns must be equal.\n");
	}
	
	else if(n == 8) {
		next_line;// Inverse of A
		printf("This is the inverse of matrix A:\n");
		if(detMatrix(A.array,A.m) != 0) {
			printf("Inverse:\n");
			inv.m=A.m;
			inv.n=A.n;
			c.m=A.m;
			c.n=A.n;
			get_cofactor(A.array,c.array,A.m);
			trans_invMatrix(A.array,c.array,inv.array, A.n);
			A=inv;
			printMatrix(A);
		}
		else
			printf("\nError!\nThis matrix does not have inversion.\nIts determinant must not be zero.\n");
		}
	
	
	else if(n == 9) {
		next_line;
		next_line;// Inverse of B
		printf("This is the inverse of matrix B:\n");
		if(detMatrix(B.array,B.m) != 0) {
			printf("Inverse:\n");
			inv.m=B.m;
			inv.n=B.n;
			c.m=B.m;
			c.n=B.n;
			get_cofactor(B.array,c.array,B.m);
			trans_invMatrix(B.array,c.array,inv.array, B.n);
			B=inv;
			printMatrix(B);
		}
		else
			printf("\nError!\nThis matrix does not have determinant.\nIts determinant must not be zero.\n");
	}
	
	else if(n == 10) {
		//calculating transpose of A
		T.m=A.n;
		T.n=A.m;
		transMatrix(A.array,T.array,A.m,A.n);
		A.n=T.n;
		A.m=T.m;
		A=T;
		printMatrix(A);
		next_line;
	}
	
	else if(n == 11) {
		//calculating transpose of B
		T.m=B.n;
		T.n=B.m;
		transMatrix(B.array,T.array,B.m,B.n);
		B.m=T.m;
		B.n=T.n;
		B=T;
		printMatrix(B);
		next_line;
	}
	
	else if(n == 12) 
		printMatrix_A_in_file(A);
	
	else if(n == 13)
		printMatrix_B_in_file(B);
	
	return 0; // End of main function
}

// Recieve a matrix from console
struct Matrix readMatrix() {
	struct Matrix a;
	int i, j;
	
	printf("Enter rows and cols:\n");
	scanf("%d %d", &a.m, &a.n);
	
	for(i=0;i<a.m;i++)
		for(j=0;j<a.n;j++) {
			printf("Enter the [%d][%d] argument:\n", i+1, j+1);
			scanf("%f", &a.array[i][j]);
		}
	
	return a;
}

// Read matrix A from a file named a.txt
struct Matrix readMatrix_A_from_file() {
	struct Matrix A;
	int i, j, f;
	FILE *matrix_a;
	
	matrix_a=fopen("a.txt","r");
	
	fscanf(matrix_a,"%d %c %d", &A.m, &f, &A.n);
	
	for(i=0;i<A.m;i++)
		for(j=0;j<A.n;j++) {
			fscanf(matrix_a,"%f", &A.array[i][j]);
		}
		
	fclose(matrix_a);
	
	return A;
}

// Read matrix B from a file named b.txt
struct Matrix readMatrix_B_from_file() {
	struct Matrix B;
	int i, j, f;
	FILE *matrix_b;
	
	matrix_b=fopen("b.txt","r");
	
	fscanf(matrix_b,"%d %c %d", &B.m, &f, &B.n);
	
	for(i=0;i<B.m;i++)
	for(j=0;j<B.n;j++) {
			fscanf(matrix_b,"%f", &B.array[i][j]);
		}
		
	fclose(matrix_b);
	
	return B;
}

// Displays the matrix of the entered structure
void printMatrix(struct Matrix a) {
	printf("Matrix is %d*%d\n", a.m, a.n);
	int i, j;
	
	for(i=0;i<a.m;i++) {
		for(j=0;j<a.n;j++)
			printf("%9f ", a.array[i][j]);
			
		printf("\n");
	}
}

// Writes matrix A in a file named A1.txt
void printMatrix_A_in_file(struct Matrix a) {
	int i, j;
	FILE *matrix_a;
	
	matrix_a=fopen("A1.txt","w");
	
	fprintf(matrix_a,"%d * %d\n", a.m, a.n);
	
	for(i=0;i<a.m;i++) {
		for(j=0;j<a.n;j++)
			fprintf(matrix_a,"%9f ",a.array[i][j]);
		
		fprintf(matrix_a,"\n");
	}
	
	fclose(matrix_a);
}

// Writes matrix B in a file named B2.txt
void printMatrix_B_in_file(struct Matrix b) {
	int i, j;
	FILE *matrix_b;
	
	matrix_b=fopen("B2.txt","w");
	
	fprintf(matrix_b,"%d * %d\n", b.m, b.n);
	
	for(i=0;i<b.m;i++) {
		for(j=0;j<b.n;j++)
			fprintf(matrix_b,"%9f ",b.array[i][j]);
		
		fprintf(matrix_b,"\n");
	}
	
	fclose(matrix_b);
}

// Calculates the addition of two matrices
int addMatrix(struct Matrix *a,struct Matrix *b,struct Matrix *c) {
	if(a->m == b->m && a->n == b->n)
	{
		int i, j;
		c->m = a->m;
		c->n = a->n;
		
		for(i=0;i<a->m;i++) {
			for(j=0;j<a->n;j++) {
				*(*(c->array+i)+j) = *(*(a->array+i)+j) + *(*(b->array+i)+j);
			}
		}
		
		return 1;
	}
	
	return 0;
}

// Calculates the substraction of two matrices
int subMatrix(struct Matrix *a,struct Matrix *b,struct Matrix *c) {
	if(a->m == b->m && a->n == b->n) {
		int i, j;
		c->m = a->m;
		c->n = a->n;
		
		for(i=0;i<a->m;i++) {
			for(j=0;j<a->n;j++) {
				*(*(c->array+i)+j) = *(*(a->array+i)+j) - *(*(b->array+i)+j);
			}
		}
		
		return 1;
	}
	
	return 0;
}

// Calculates the multiplication of two matrices
int mulMatrix(struct Matrix *a,struct Matrix *b,struct Matrix *c) {
	if(a->n == b->m) {
		int i, j, k;
		c->m = a->m;
		c->n = b->n;
		
		for(i = 0; i < a->m; ++i) {
			for(j = 0; j < b->n; ++j) {
				*(*(c->array+i)+j) = 0;
			}
		}

		for(i = 0; i < a->m; ++i) {
			for(j = 0; j < b->n; ++j) {
				for(k = 0; k < a->n; ++k) {
					*(*(c->array+i)+j) += *(*(a->array+i)+k) * *(*(b->array+k)+j);
				}
			}
		}
		
		return 1;
	}
	return 0;
	
}

// This function is used in detMatirx function
void getCofactor(float A[][MAX_SIZE], float temp[][MAX_SIZE], int p, int q, int n) 
{
    int i = 0, j = 0, row, col;
  
    // Looping for each element of the matrix
    for (row = 0; row < n; row++) {
        for (col = 0; col < n; col++) {
            //  Copying into temporary matrix only those element
            //  which are not in given row and column
            if (row != p && col != q) {
                temp[i][j++] = A[row][col];

                // Row is filled, so increase row index and
                // reset col index
                if (j == n - 1) {
                    j = 0;
                    i++;
                }
            }
        }
    }
}

// Calculates the determinant of a matrix by using getCofactor function defined above
float detMatrix(float A[][MAX_SIZE], int n)
{
    float D = 0;
	int f;
    
    if (n == 1)
        return A[0][0];

    float temp[MAX_SIZE][MAX_SIZE];

    float sign = 1;

    for (f = 0; f < n; f++)
    {
        getCofactor(A, temp, 0, f, n);
        D += sign * A[0][f] * detMatrix(temp, n - 1);

        sign = -sign;
    }
  
    return D;
}

// First calculate transpose of a matrix then calculates inverse
// This function is only useful to calculate the inverse of a matirx
float trans_invMatrix(float matrix[][MAX_SIZE], float matrix_cofactor[][MAX_SIZE], float m_inverse[][MAX_SIZE], int size) {
    int i,j;
    float m_transpose[MAX_SIZE][MAX_SIZE],d;
 
    for(i=0;i<size;i++)
        for(j=0;j<size;j++)
            m_transpose[i][j]=matrix_cofactor[j][i];
    
	d=detMatrix(matrix,size);
    
	for(i=0;i<size;i++)
        for(j=0;j<size;j++)
            m_inverse[i][j]=m_transpose[i][j] / d;
        
        
}

// Calculates the co factor of a matrix
// This function is useful for calculating inverse of a matrix
float get_cofactor(float matrix[][MAX_SIZE],float matrix_cofactor[][MAX_SIZE],int size) {
    float m_cofactor[MAX_SIZE][MAX_SIZE];
    int p,q,m,n,i,j;
   
    for (q=0;q<size;q++) {
        for (p=0;p<size;p++) {
            m=0;
            n=0;
            for (i=0;i<size;i++) {
                for (j=0;j<size;j++) {
                    if (i != q && j != p) {
                        m_cofactor[m][n]=matrix[i][j];
					    if (n<(size-2))
                           n++;
                        else {
                            n=0;
                            m++;
                        }
                    }
                }
            }
            matrix_cofactor[q][p]=pow(-1,q + p) * detMatrix(m_cofactor,size-1);
        }
    }    
}

// This function is only for calculating transpose of a matrix
void transMatrix(float A[][MAX_SIZE], float B[][MAX_SIZE],int m, int n) {
    int i, j;
    for (i = 0; i < m; i++)
        for (j = 0; j < n; j++)
            B[j][i] = A[i][j];
}
